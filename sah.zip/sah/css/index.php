<?php
    header('Location: ../Naslovnica.php');
?>