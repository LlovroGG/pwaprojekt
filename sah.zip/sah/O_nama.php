<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="O_nama.css">
    <link rel="apple-touch-icon" sizes="180x180" href="images/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="images/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon/favicon-16x16.png">
    <link rel="manifest" href="images/favicon/site.webmanifest">
    <title>O_nama</title>
    <?php
    session_start();

    $servername="localhost";
    $username= "root";
    $password= "";
    $dbname= "sah";
    $port="3307";

    $dbc= mysqli_connect($servername, $username, $password, $dbname, $port) or
    die('Error connecting to MySQL server.'. mysqli_connect_error());
    if(!(isset($_SESSION["username"])) || !(isset($_SESSION["password"]))){
        header('Location: index.php');
    }
    $ime = $_SESSION["username"];
    $lozinka = $_SESSION["password"];

    $sql2 = 'SELECT korisnickoIme, lozinka, adminornot FROM korisnik WHERE korisnickoIme = ?';

    $stmt=mysqli_stmt_init($dbc);

        if (mysqli_stmt_prepare($stmt, $sql2)){
            mysqli_stmt_bind_param($stmt,'s',$ime);
        
            mysqli_stmt_execute($stmt);
            mysqli_stmt_store_result($stmt);
        }

        mysqli_stmt_bind_result($stmt, $a, $b, $c);
        mysqli_stmt_fetch($stmt);

        if($lozinka!=$b){
            header('Location: index.php');
        }
?>
</head>
<body>
    <header>
        <img src="images/logo.png" alt="apstraktni top (logo)">
        <nav>
            <ul>
                <li><a href="Naslovnica.php">Naslovnica</a></li>
                <li><a id="drugilink" href="Kontakt/Kontakt.php">Kontakt</a></li>
                <li><a id="trecilink" href="Novosti.php">Novosti</a></li>
                <li><a id="cetvrtilink" href="Trgovina.php">Trgovina</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <h1>O nama</h1>

        <section class="Organizacija">
            <h2>Organizacija</h2>
            <p>Mi smo tajna šahovska organizacija koju je osnovao član ŠŠK Koprivnice i ŠŠK Podravke Lovro Koštić. Lovro je dugo vrijeme bio među 100 najbolji kadeta u državi po FIDE rejtingu (23 mjeseca između 2014. i 2018. godine, najbolji plasman je 59. mjesto u siječnju 2015. do 16 godina i 2. mjesto do 12 godina) </p>
            <iframe src="https://www.youtube.com/embed/ej_fnsdsksA" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
        </section>

        <section class="dva">
            <h2>Veličina organizacije</h2>
            <p>U organizaciju se nažalost još nitko nije prijavio, ali nadamo se da vi to želite!</p>
            <img src="images/plakanje.png" alt="plakanje">
        </section>

        <section class="tri">
            <h2>Pazite se!</h2>
            <p>Samo nemojte pričati o organizacije, ako otkrijete tajnu stići će vas ljuti konj.</p>
            <img src="images/strah.jpg" alt="strah">
        </section>
    </main>

    <section class="sidebar">
        <h2>Ovo je ljuti konj</h2>
        <img src="images/konj.jpg" alt="konj">
    </section>
    
    <footer>
        <h3>Izradio :</h3>
        <h2>Lovro Koštić, 0246111471 </h2>
    </footer>

</body>



</html>