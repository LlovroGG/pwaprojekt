<!DOCTYPE html>

<head> 
   <meta charset="UTF-8">  
   <script type="text/javascript" src="jquery-1.11.0.js"></script>
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
   <link rel="stylesheet" href="css/prijava.css">
</head>

<body>

    <form action="" name="prijava" method="post">

      <label for="firstname">Korisničko ime</label>
      <input type="text" name="firstname" id="firstname"/>
  
      <label for="password">Lozinka</label>
      <input type="password" name="password" id="password"/>
  
      <button type="submit">Login</button>
      <a href="Registracija.php" id="link">Registracija</a>
  
    </form>

    <?php
    $servername="localhost";
    $username= "root";
    $password= "";
    $dbname= "sah";
    $port="3307";

    $dbc= mysqli_connect($servername, $username, $password, $dbname, $port) or
    die('Error connecting to MySQL server.'. mysqli_connect_error());

    if(isset($_POST["firstname"]) && isset($_POST["password"])){
        $ime = $_POST["firstname"];
        $lozinka = $_POST["password"];

        $sql2 = 'SELECT korisnickoIme, lozinka, adminornot FROM korisnik WHERE korisnickoIme = ?';

        $stmt=mysqli_stmt_init($dbc);

        if (mysqli_stmt_prepare($stmt, $sql2)){
            mysqli_stmt_bind_param($stmt,'s',$ime);
        
            mysqli_stmt_execute($stmt);
            mysqli_stmt_store_result($stmt);
        }

        mysqli_stmt_bind_result($stmt, $a, $b, $c);
        mysqli_stmt_fetch($stmt);

        if(password_verify($lozinka, $b)){
            session_start();
            $_SESSION['username']=$ime;
            $_SESSION['password']=$b;
            $_SESSION['admin']=$c;
            header('Location: Naslovnica.php');
        }

        else{
            echo "<p id='link'>Unijeli ste pogrešno korisničko ime ili lozinku</p>";
        }

        mysqli_close($dbc);
    }
?>
</body>