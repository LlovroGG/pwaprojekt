<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="admin.css">
</head>
<body>
    
</body>


<?php
    session_start();

    $id=$_GET['id'];

    if($_SESSION["admin"]==0){
        header('Location: index.php');
    }
    $servername="localhost";
    $username= "root";
    $password= "";
    $dbname= "sah";
    $port="3307";

    $dbc= mysqli_connect($servername, $username, $password, $dbname, $port) or
    die('Error connecting to MySQL server.'. mysqli_connect_error());


    $sql2 = 'SELECT * FROM kontakt WHERE id='.$id;
    $rezultat=mysqli_query($dbc, $sql2);
    $i=0;
    while($row = mysqli_fetch_array($rezultat)){
        $i=$i+1;
        echo
        '<form method="post" enctype="multipart/form-data">
            <p>
            <label>Ime i prezime: <input type="text" name="ime" placeholder="'.$row['imeprezime'].'" required></label><br>
            <label>Datum rođenja: <input type="date" name="datum" required></label><br>
            </p>
            <p>Koliko iskustva imate u šahu: <br>
                <label><input type="radio" name="iskustvo" value="0" checked >Nemam</label>
                <label><input type="radio" name="iskustvo" value="1">Manje od godine</label>
                <label><input type="radio" name="iskustvo" value="2">Manje od dvije godine</label>
                <label><input type="radio" name="iskustvo" value="3">Više od dvije godine</label>
            </p>
            <p>Na kojim web stranicama igrate šah <br>
                <label><input type="checkbox" name="stranice" value="1">Lichess</label>
                <label><input type="checkbox" name="stranice" value="2">Chess.com</label>
            </p>
            <p>
            <label>Koliki vam je FIDE rejting:
                <select name="rtg" required>
                    <option value=""> Rejting </option>
                    <option value="1" selected >Nemam ga</option>
                    <option value="2">Manji od 1200</option>
                    <option value="3">Manji od 1400</option>
                    <option value="4">Manji od 1800</option>
                    <option value="5">Veći od 1800</option>
                </select>
            </label>
            </p>
            <div class="form-item"> <label for="pphoto"><p>Slika: </p></label> <div class="form-field"> <input type="file" accept="image/jpg,image/gif" class="input-text" name="pphoto"/> </div> </div>
            <img src="Kontakt/img/'.$row['slika'].'">
            <div class="gumbi">
                <a href="mailto:lkostic@tvz.hr">Email</a>
                <input type="submit" value="Update">
                <input type="reset">
            </div>
            <span class="span">

            </span>
        </form>';
    }
    mysqli_close($dbc);
?>

<?php
if(isset($_POST["ime"]) && isset($_POST["iskustvo"]) && isset($_POST["rtg"])){
    

    $servername="localhost";
    $username= "root";
    $password= "";
    $dbname= "sah";
    $port="3307";

    $dbc= mysqli_connect($servername, $username, $password, $dbname, $port) or
    die('Error connecting to MySQL server.'. mysqli_connect_error());

    $ime = $_POST["ime"];
    $datum = date($_POST["datum"]);
    $iskustvo = $_POST["iskustvo"];
    $rtg = $_POST["rtg"];
    $photo = $_FILES["pphoto"]["name"];
    $target_dir = 'Kontakt/img/'.$photo;
    move_uploaded_file($_FILES["pphoto"]["tmp_name"], $target_dir);

    $sql = 'UPDATE kontakt SET imeprezime="'.$ime.'", datum="'.$datum.'", iskustvo='.$iskustvo.', fide='.$rtg.', slika="'.$photo.'" WHERE id='.$_GET['id'];
    $result = mysqli_query($dbc, $sql);
        
    mysqli_close($dbc);
    
        
}
?>
</html>