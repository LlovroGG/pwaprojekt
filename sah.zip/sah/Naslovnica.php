<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Naslovnica.css">
    <link rel="apple-touch-icon" sizes="180x180" href="images/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="images/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon/favicon-16x16.png">
    <link rel="manifest" href="images/favicon/site.webmanifest">
    <title>Naslovnica</title>
</head>
<?php
    session_start();

    $servername="localhost";
    $username= "root";
    $password= "";
    $dbname= "sah";
    $port="3307";

    $dbc= mysqli_connect($servername, $username, $password, $dbname, $port) or
    die('Error connecting to MySQL server.'. mysqli_connect_error());
    if(!(isset($_SESSION["username"])) || !(isset($_SESSION["password"]))){
        header('Location: index.php');
    }
    $ime = $_SESSION["username"];
    $lozinka = $_SESSION["password"];

    $sql2 = 'SELECT korisnickoIme, lozinka, adminornot FROM korisnik WHERE korisnickoIme = ?';

    $stmt=mysqli_stmt_init($dbc);

        if (mysqli_stmt_prepare($stmt, $sql2)){
            mysqli_stmt_bind_param($stmt,'s',$ime);
        
            mysqli_stmt_execute($stmt);
            mysqli_stmt_store_result($stmt);
        }

        mysqli_stmt_bind_result($stmt, $a, $b, $c);
        mysqli_stmt_fetch($stmt);

        if($lozinka!=$b){
            header('Location: index.php');
        }
?>
<body>
    <header>
        <img src="images/logo.png" alt="apstraktni top (logo)">
        <nav>
            <ul>
                <li><a href="O_nama.php">O nama</a></li>
                <li><a id="drugilink" href="Kontakt/Kontakt.php">Kontakt</a></li>
                <li><a id="trecilink" href="Novosti.php">Novosti</a></li>
                <li><a id="cetvrtilink" href="Trgovina.php">Trgovina</a></li>
            </ul>
        </nav>
    </header>
    <div class="poglavlja">
        <a href="#ploca">Ploča</a>
        <a id="a2" href="#figure">Figure</a>
        <a id="a3" href="#tablica">Tablica</a>
    </div>
    <main>
        <h1>Šah</h1>
        <hr>

        <p id="uvod">Šah je igra za dva igrača u kojoj jedan igrač upravlja sa 16 bijelih, a drugi sa 16 crnih figura. Svaki igrač naizmjenično odigra jedan potez sve dok partija ne završi. Partija završava odlučeno ako se jedan od igrača preda, ako igrač ne može spasiti svog kralja od napada protivničkih figura u jednom potezu (mat) ili ako igraču istekne vrijeme (samo ako se koristi šahovski sat). Partija završava neodlučeno (remijem) ako se igrači dogovore za remi, ako igrač koji je na potezu ne može odigrati legalan potez i kralj mu nije napadnut (pat), ako se odigra 50 poteza bez da obojica igrača ne pomaknu pješaka ili ne pojedu protivničku figuru ili ako obojica igrača nemaju figure s kojima bi mogli matirati.</p>

        <article id="ploca">
            <img src="images/ploca.png" alt="šahovska ploča na početku igre">
            <h2>Šahovska ploča</h2>
            <p> 
                Šahovska ploča sastoji se od 64 polja. Sadrži osam redaka i stupaca popunjena sa naizmjeničnim bijelim i crnim poljima. Svaki redak označen je sa brojem (1-8), a svaki stupac sa slovom (A-H). Na jednom polju može najviše biti jedna šahovska figura. U slučaju da se na nekom polju nalazi protivnička figura, a mi želimo staviti našu figuru na to polje, protivnička figura izlazi iz igre i na to polje dolazi naša figura (jedenje). 
            </p>
            <h3>Kako se na početku igre postavljaju figure?</h3>
            <p>
                Na početku igre bijele figure se stavljaju na prvi i drugi red, a crne na sedmi i osmi. U kut ploče se stavljaju topovi, pored njih dolaze skakači, s druge strane skakača su lovci, a u sredini se nalaze kralj i dama. Kralja se stavlja na suprotnu boju polja, a damu na istu boju polja kao figure (bijeli kralj se nalazi na crnom polju, a bijela dama na bijelom). Ispred tih figura dolazi jedan red pješaka. 
            </p>
        </article>

        <section id="figure">
            <h2> Šahovske figure </h2>
                <article class="pjesak">
                    <img src="images/pjesak.png" alt="Pješak">
                    <div>
                    <h3>Pješak (Pijun)</h3>
                    <p>Pješak je najmanja figura na ploči. On ima neobičan način kretanja. Pješak jede figure samo u koso, a dok ne jede može se kretati samo prema gore za jedno polje osim ako to nije prvi potez s tim pješakom, u tom slučaju se može pomaknuti za jedno ili dva polja prema gore.</p>
                    <p>Pješak uz to ima još dva posebna poteza: promocija i en passant. Promociju postiže tako da dođe na protivnički prvi red i onda se pretvori u damu, topa, lovca ili skakača (igrač koji promovira pješaka bira u što će se pješak pretvoriti). En passant je najkompliciranije pravilo u šahu, objašnjenje pogledajte u
                         <a href="https://www.youtube.com/shorts/FzBMVgL1jbk" target="_blank">videu</a>. Ako se pješak pomakne za dva polja, a protivnički pješak se nalazi pored njega onda ga taj pješak može pojesti isto kao i da se pomaknuo samo za jedno polje, ali samo sljedeći potez. </p>
                    </div>
                    <img id="kretanjep" src="images/pjesak_kretanje.png" alt="kretanje pješaka">
                    <img id="enpassant" src="images/en_passant.png" alt="en passant">
                </article>
                <article class="skakac">
                    <h3>Skakač (konj)</h3>
                    <p>Skakač je posebna figura zato što on može „preskočiti“ druge figure dok se kreće. U jednom potezu skakač se može napraviti malo slovo „L“.</p>
                    <img id="skakac" src="images/skakac.png" alt="Skakač">
                    <img src="images/skakac_kretanje.png" alt="kretanje skakač">
                </article>
                <article class="lovac">
                    <h3>Lovac</h3>
                    <p>Lovac za razliku od pješaka se uvijek kreće isto i nema nikakvih posebnih pravila. U jednom potezu se može kretati dijagonalno sve dok ne dođe do neke druge figure ili ruba ploče.</p>
                    <img id="lovac" src="images/lovac.png" alt="Lovac">
                    <img src="images/lovac_kretanje.png" alt="kretanje lovac">
                </article>
                <article class="dama">
                    <h3>Dama (Kraljica)</h3>
                    <p>Dama je najmoćnija figura na šahovskoj ploči. Može se kretati dijagonalno poput lovaca i ravno poput topa.</p>
                    <img id="dama" src="images/dama.png" alt="Dama">
                    <img src="images/dama_kretanje.png" alt="kretanje dama">
                </article>
                <article class="top">
                    <h3>Top</h3>
                    <p>Top je figura slična lovcu, jedina razlika između njih je način kretanja. Top se kreće ravno, a ne dijagonalno.</p>
                    <img id="top" src="images/top.png" alt="Top">
                    <img src="images/top_kretanje.png" alt="kretanje top">
                </article>
                <article class="kralj">
                    <h3>Kralj</h3>
                    <img src="images/kralj.png" alt="Kralj">
                    <p id="kralj1">Kralj je najvrjednija figura na ploči. Može se kretati samo jedno polje u svaku stranu po potezu. Kada je kralj napadnut taj napad se <b>MORA</b> zaustaviti, ne smiješ završiti svoj potez i ostaviti napadnutog kralja. Ukoliko je nemoguće zaustaviti napad, igrač gubi partiju. </p>
                    <p id="kralj2">Kralj također kao i pješak ima poseban potez. Njegov poseban potez se zove rohada. Ovdje je <a href="https://www.youtube.com/shorts/0boZ1OZSHeE" target="_blank">link</a> na video koji ju objašnjava. 
                        Za taj potez je potreban kralj i top koji se nisu pomaknuli s početnog polja, također polje na kojem se nalazi kralj i dva polja između kralja i topa bliže kralju ne smiju biti napadnuta. U tom slučaju kralj se može pomaknuti za dva polja prema topu i top ga onda preskoči.
                    </p>
                
                    <div>
                        <img src="images/sah1.png" alt="Kralj je napadnut">
                        <img id="strelica1" src="images/strelica.jpg" alt="Strelica">
                        <img src="images/sah2.png" alt="Mogući potezi">

                        <img src="images/rohada.png" alt="Prije rohade">
                        <img id="strelica2" src="images/strelica.jpg" alt="Strelica">
                        <img src="images/rohada2.png" alt="Nakon rohade">
                    </div>    
                </article>
        </section>
        <section id="tablica">
            <h2>Neke osobe u svijetu šaha koje bih ja izdvojio</h2>
            <table>
                <tr id="tr1">
                    <th>Ime i prezime</th>
                    <td>Magnus Carlsen</td>
                    <td>Garry Kasparov</td>
                    <td>Ivan Šarić</td>
                    <td>Antonio Radić</td>
                </tr>
                <tr id="tr2">
                    <td>Slika</td>
                    <td><img src="images/Magnus.png" alt=""></td>
                    <td><img src="images/Garry.png" alt=""></td>
                    <td><img src="images/Ivan.jpg" alt=""></td>
                    <td><img src="images/Antonio.png" alt=""></td>
                </tr>
                <tr id="tr3">
                    <td>Državljanstvo</td>
                    <td>Norvežanin<img src="images/norveska.jpg" alt=""></td>
                    <td>Rus<img src="images/Rusija.png" alt=""></td>
                    <td id="Hrv" colspan="2"><img src="images/Hrvatska.png" alt=""><p>Hrvat</p></td>
                </tr>
                <tr id="tr4">
                    <td>Šahovska titula</td>
                    <td colspan="3">Velemajstor (GM)</td>
                    <td>Majstorski kandidat(MK)</td>
                </tr>
                <tr id="tr5">
                    <td>Po čemu su posebni</td>
                    <td>Najviši FIDE rejting u povijesti šaha (2882) i trenutni najviši FIDE rejting (2853). Svjetski prvak od 2013. do 2023. godine</td>
                    <td>2. Najviši FIDE rejting u povjesti šaha (2851). Trenutno nije aktivan u šahu. Jedan od najboljih šahista svih vremena</td>
                    <td>Trenutno najbolji šahist iz Hrvatske. Nalazi se na 78. mjestu s rejtingom 2663.</td>
                    <td>Youtuber s 1,29 milijuna pretplatnika i 677 miljiuna pregleda. Jedan od najvećih youtubera kojima je šah glavni sadržaj.</td>
                </tr>
                <tr id="tr6">
                    <td>Nešto više o njima</td>
                    <td><a href="https://en.wikipedia.org/wiki/Magnus_Carlsen">Link</a></td>
                    <td><a href="https://en.wikipedia.org/wiki/Garry_Kasparov">Link</a></td>
                    <td><a href="https://hr.wikipedia.org/wiki/Ivan_%C5%A0ari%C4%87_(%C5%A1ahist)">Link</a></td>
                    <td><a href="https://en.wikipedia.org/wiki/Agadmator">Link</a></td>
                </tr>
            </table>
        </section>
    </main>
    <footer>
        <h3>Izradio :</h3>
        <h2>Lovro Koštić, 0246111471 </h2>
    </footer>
</body>
</html>