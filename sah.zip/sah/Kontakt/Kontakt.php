<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../Kontakt.css">
    <link rel="apple-touch-icon" sizes="180x180" href="../images/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="../images/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="../images/favicon/favicon-16x16.png">
    <link rel="manifest" href="../images/favicon/site.webmanifest">
    <title>Kontakt</title>
    <?php
    session_start();

    $servername="localhost";
    $username= "root";
    $password= "";
    $dbname= "sah";
    $port="3307";

    $dbc= mysqli_connect($servername, $username, $password, $dbname, $port) or
    die('Error connecting to MySQL server.'. mysqli_connect_error());
    if(!(isset($_SESSION["username"])) || !(isset($_SESSION["password"]))){
        header('Location: index.php');
    }
    $ime = $_SESSION["username"];
    $lozinka = $_SESSION["password"];

    $sql2 = 'SELECT korisnickoIme, lozinka, adminornot FROM korisnik WHERE korisnickoIme = ?';

    $stmt=mysqli_stmt_init($dbc);

        if (mysqli_stmt_prepare($stmt, $sql2)){
            mysqli_stmt_bind_param($stmt,'s',$ime);
        
            mysqli_stmt_execute($stmt);
            mysqli_stmt_store_result($stmt);
        }

        mysqli_stmt_bind_result($stmt, $a, $b, $c);
        mysqli_stmt_fetch($stmt);

        if($lozinka!=$b){
            header('Location: index.php');
        }
?>
</head>
<body>
    <header>
        <img src="../images/logo.png" alt="apstraktni top (logo)">
        <nav>
            <ul>
                <li><a href="../O_nama.php">O nama</a></li>
                <li><a id="drugilink" href="../Naslovnica.php">Naslovnica</a></li>
                <li><a id="trecilink" href="../Novosti.php">Novosti</a></li>
                <li><a id="cetvrtilink" href="../admin.php">ADMIN</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <img src="../images/Upitnik.png" alt="Upitnik">
        <form method="post" enctype="multipart/form-data" action="kontakt2.php">
            <p>
            <label>Ime i prezime: <input type="text" name="ime" placeholder="Mario Mandžukić" required></label><br>
            <label>Datum rođenja: <input type="date" name="datum" required></label><br>
            </p>
            <p>Koliko iskustva imate u šahu: <br>
                <label><input type="radio" name="iskustvo" value="0" checked >Nemam</label>
                <label><input type="radio" name="iskustvo" value="1">Manje od godine</label>
                <label><input type="radio" name="iskustvo" value="2">Manje od dvije godine</label>
                <label><input type="radio" name="iskustvo" value="3">Više od dvije godine</label>
            </p>
            <p>Na kojim web stranicama igrate šah <br>
                <label><input type="checkbox" name="stranice" value="1">Lichess</label>
                <label><input type="checkbox" name="stranice" value="2">Chess.com</label>
            </p>
            <p>
            <label>Koliki vam je FIDE rejting:
                <select name="rtg" required>
                    <option value=""> Rejting </option>
                    <option value="1" selected >Nemam ga</option>
                    <option value="2">Manji od 1200</option>
                    <option value="3">Manji od 1400</option>
                    <option value="4">Manji od 1800</option>
                    <option value="5">Veći od 1800</option>
                </select>
            </label>
            </p>
            <div class="form-item"> <label for="pphoto"><p>Slika: </p></label> <div class="form-field"> <input type="file" accept="image/jpg,image/gif" class="input-text" name="pphoto"/> </div> </div>
            <div class="gumbi">
                <a href="mailto:lkostic@tvz.hr">Email</a>
                <input type="submit">
                <input type="reset">
            </div>
            <span class="span">

            </span>
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d88421.01162755428!2d16.73880022379079!3d46.16753804829569!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x476627031a318147%3A0xbe043a049b25af09!2sKoprivnica!5e0!3m2!1shr!2shr!4v1685650438214!5m2!1shr!2shr" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </form>

    </main>

    <footer>
        <h3>Izradio :</h3>
        <h2>Lovro Koštić, 0246111471 </h2>
    </footer>
</body>
</html>