<?php
if(isset($_POST["ime"]) && isset($_POST["iskustvo"]) && isset($_POST["rtg"])){
    

    $servername="localhost";
    $username= "root";
    $password= "";
    $dbname= "sah";
    $port="3307";

    $dbc= mysqli_connect($servername, $username, $password, $dbname, $port) or
    die('Error connecting to MySQL server.'. mysqli_connect_error());

    $ime = $_POST["ime"];
    $datum = date($_POST["datum"]);
    echo $datum;
    $iskustvo = $_POST["iskustvo"];
    $rtg = $_POST["rtg"];
    $photo = $_FILES["pphoto"]["name"];
    $target_dir = 'img/'.$photo;
    move_uploaded_file($_FILES["pphoto"]["tmp_name"], $target_dir);

    $sql = 'INSERT INTO kontakt (imeprezime, datum, iskustvo, fide, slika) VALUES (?, ?, ?, ?, ?)';
        $stmt = mysqli_stmt_init($dbc);

        if (mysqli_stmt_prepare($stmt, $sql)){
            mysqli_stmt_bind_param($stmt,'ssiis',$ime,$datum,$iskustvo,$rtg,$photo);
            mysqli_stmt_execute($stmt);
        }
        
        mysqli_close($dbc);
    
        
}
header('Location: Kontakt.php');
?>