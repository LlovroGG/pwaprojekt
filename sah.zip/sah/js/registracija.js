
$(function() {
    $("form[name='prijava']").validate({
    rules: {
        firstname: {
        required: true,
        minlength: 5,
        
    },
        password1: {
        required: true,
        minlength: 8,
        equalTo: "#password2",
        
        },
        password2:{
        required: true
        }
    },
    messages: {
        firstname: {
        required: "Potrebno je upisati korisničko ime",
        minlength: "Korisničko ime nesmije biti kraće od 5 znakova",
        },
        password1: {
        required: "Potrebno je upisati lozinku",
        equalTo: "Lozinke trebaju biti iste",
        minlength: "Lozinka nesmije biti manje od 8 znakova"
        },
        password2: {
            required: "Potrebno je ponoviti lozinku lozinku"
        }
    },

    submitHandler: function(form) {
        form.submit();
    }
    });
});
