<?php
    session_start();

    $id=$_GET['id'];

    if($_SESSION["admin"]==0){
        header('Location: index.php');
    }
    $servername="localhost";
    $username= "root";
    $password= "";
    $dbname= "sah";
    $port="3307";

    $dbc= mysqli_connect($servername, $username, $password, $dbname, $port) or
    die('Error connecting to MySQL server.'. mysqli_connect_error());

    if(isset($_GET['id'])){ 
        $id=$_GET['id'];
        $query = "DELETE FROM kontakt WHERE id=$id ";
        $result = mysqli_query($dbc, $query);
    }

    header("Location: admin.php")
?>