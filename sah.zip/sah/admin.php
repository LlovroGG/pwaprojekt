<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="admin.css">
</head>
<body>
    
</body>


<?php
    session_start();
    if($_SESSION["admin"]==0){
        header('Location: index.php');
    }
    $servername="localhost";
    $username= "root";
    $password= "";
    $dbname= "sah";
    $port="3307";

    $dbc= mysqli_connect($servername, $username, $password, $dbname, $port) or
    die('Error connecting to MySQL server.'. mysqli_connect_error());


    $sql2 = 'SELECT * FROM kontakt';
    $rezultat=mysqli_query($dbc, $sql2);
    $i=0;
    echo
    "<table>";
    while($row = mysqli_fetch_array($rezultat)){
        $i=$i+1;
        echo
        "<tr id=tr$i>
                <td id='jedan'>".$row['id']."</td>
                <td id='dva'>".$row['imeprezime']."</td>
                <td id='tri'><a href='admin2.php?id=".$row['id']."'>Edit</a></td>
                <td id='tri'><a href='admin3.php?id=".$row['id']."'>Izbriši</a></td>
        </tr>";
    }
    echo
    "</table>";
    mysqli_close($dbc);
?>
</html>