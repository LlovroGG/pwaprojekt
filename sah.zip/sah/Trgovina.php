<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/41f8bc7d33.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="Trgovina.css">
    <link rel="apple-touch-icon" sizes="180x180" href="images/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="images/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon/favicon-16x16.png">
    <link rel="manifest" href="images/favicon/site.webmanifest">
    <title>Trgovina</title>
    <?php
    session_start();

    $servername="localhost";
    $username= "root";
    $password= "";
    $dbname= "sah";
    $port="3307";

    $dbc= mysqli_connect($servername, $username, $password, $dbname, $port) or
    die('Error connecting to MySQL server.'. mysqli_connect_error());
    if(!(isset($_SESSION["username"])) || !(isset($_SESSION["password"]))){
        header('Location: index.php');
    }
    $ime = $_SESSION["username"];
    $lozinka = $_SESSION["password"];

    $sql2 = 'SELECT korisnickoIme, lozinka, adminornot FROM korisnik WHERE korisnickoIme = ?';

    $stmt=mysqli_stmt_init($dbc);

        if (mysqli_stmt_prepare($stmt, $sql2)){
            mysqli_stmt_bind_param($stmt,'s',$ime);
        
            mysqli_stmt_execute($stmt);
            mysqli_stmt_store_result($stmt);
        }

        mysqli_stmt_bind_result($stmt, $a, $b, $c);
        mysqli_stmt_fetch($stmt);

        if($lozinka!=$b){
            header('Location: index.php');
        }
?>
</head>
<body>
    <header>
        <img src="images/logo.png" alt="apstraktni top (logo)">
        <nav>
            <ul>
                <li><a href="O_nama.php">O nama</a></li>
                <li><a id="drugilink" href="Kontakt/Kontakt.php">Kontakt</a></li>
                <li><a id="trecilink" href="Novosti.php">Novosti</a></li>
                <li><a id="cetvrtilink" href="Naslovnica.php">Naslovnica</a></li>
            </ul>
        </nav>
    </header>

    <div class="banner">
        <h1>Šahovski set na akciji!</h1>
    </div>

    <main>
        <section class="akcije">
            <article>
                <img src="images/garnitura.jpg" alt="garnitura">
                <h2>Šahovska garnitura <i class="fa-regular fa-chess-king"></i></h2>
                <p>Drvena šahovska garnitura</p>
                <p class="cijena">80 eura</p>
                <p class="ncijena">70 eura</p>
                <a href="#">Dodaj u košaricu</a>
            </article>

            <article>
                <img src="images/dgt2010.png" alt="dgt2010">
                <h2>DGT 2010 <i class="fa-solid fa-stopwatch"></i></h2>
                <p>Šahovski sat DGT 2010</p>
                <p class="cijena">40 eura</p>
                <p class="ncijena">35 eura</p>
                <a href="#">Dodaj u košaricu</a>
            </article>

            <article>
                <img src="images/dgt2010ploca.jpg" alt="garnitura + sat">
                <h2>Šahovska garnitura + DGT 2010 <i class="fa-solid fa-chess"></i> </h2>
                <p>Drvena šahovska garnitura i šahovski sat DGT 2010</p>
                <p class="cijena">100 eura</p>
                <p class="ncijena">90 eura</p>
                <a href="#">Dodaj u košaricu</a>
            </article>
        </section>

        <section class="normalne">
            <article>
                <img src="images/vrecica.jpeg" alt="vrecica">
                <h2>Platnena vrećica</h2>
                <p>Vrećica za šahovske figure</p>
                <p class="cijena">5 eura</p>
                <a href="#">Dodaj u košaricu</a>
            </article>

            <article>
                <img src="images/dgt3000.jpg" alt="dgt3000">
                <h2>DGT 3000</h2>
                <p>Šahovski sat DGT 3000</p>
                <p class="cijena">65 eura</p>
                <a href="#">Dodaj u košaricu</a>
            </article>

            <article>
                <img src="images/privjesak.jpeg" alt="Privjesci">
                <h2>Privjesci</h2>
                <p>Komplet privjesaka u obliku figura</p>
                <p class="cijena">15 eura</p>
                <a href="#">Dodaj u košaricu</a>
            </article>

            <article>
                <img src="images/alkohol.jpg" alt="Alkohol šah">
                <h2>Alkohol šah</h2>
                <p>Staklene šahovska garnitura s čašama kao figure</p>
                <p class="cijena">25 eura</p>
                <a href="#">Dodaj u košaricu</a>
            </article>

            <article>
                <img src="images/4sah.jpg" alt="šah za 4">
                <h2>Šah za 4 osobe</h2>
                <p>Gornitura za šah u 4</p>
                <p class="cijena">60 eura</p>
                <a href="#">Dodaj u košaricu</a>
            </article>

            <article>
                <img src="images/salica.avif" alt="šalica">
                <h2>Šalica</h2>
                <p>Šalica za pijenje kave ili čaja</p>
                <p class="cijena">7 eura</p>
                <a href="#">Dodaj u košaricu</a>
            </article>
        </section>
    </main>
</body>
</html>