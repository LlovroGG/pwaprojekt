<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href='https://fonts.googleapis.com/css?family=Yanone Kaffeesatz' rel='stylesheet'>
    <link href="https://fonts.googleapis.com/css2?family=Geologica&family=Lora:ital@1&family=Yanone+Kaffeesatz&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="Novosti.css">
    <link rel="apple-touch-icon" sizes="180x180" href="images/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="images/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon/favicon-16x16.png">
    <link rel="manifest" href="images/favicon/site.webmanifest">
    <title>Novosti</title>

    <?php
    session_start();

    $servername="localhost";
    $username= "root";
    $password= "";
    $dbname= "sah";
    $port="3307";

    $dbc= mysqli_connect($servername, $username, $password, $dbname, $port) or
    die('Error connecting to MySQL server.'. mysqli_connect_error());
    if(!(isset($_SESSION["username"])) || !(isset($_SESSION["password"]))){
        header('Location: index.php');
    }
    $ime = $_SESSION["username"];
    $lozinka = $_SESSION["password"];

    $sql2 = 'SELECT korisnickoIme, lozinka, adminornot FROM korisnik WHERE korisnickoIme = ?';

    $stmt=mysqli_stmt_init($dbc);

        if (mysqli_stmt_prepare($stmt, $sql2)){
            mysqli_stmt_bind_param($stmt,'s',$ime);
        
            mysqli_stmt_execute($stmt);
            mysqli_stmt_store_result($stmt);
        }

        mysqli_stmt_bind_result($stmt, $a, $b, $c);
        mysqli_stmt_fetch($stmt);

        if($lozinka!=$b){
            header('Location: index.php');
        }
?>
</head>
<body>
    <header>
        <img src="images/logo.png" alt="apstraktni top (logo)">
        <nav>
            <ul>
                <li><a href="O_nama.php">O nama</a></li>
                <li><a id="drugilink" href="Kontakt/Kontakt.php">Kontakt</a></li>
                <li><a id="trecilink" href="Naslovnica.php">Naslovnica</a></li>
                <li><a id="cetvrtilink" href="Trgovina.php">Trgovina</a></li>
            </ul>
        </nav>
    </header>

    
    <div class="putanje">
        <a href="#">Turniri</a>
        <a href="#">Druženja</a>
    </div>

    <div class="Naslov">
        <h1>Novosti</h1>
    </div>

    <main class="container-fluid">

        <section class="Turniri">
            <h1>Turniri</h1>
            <div class="row">
            <article class="Gospodar col-lg-4 col-sm-6">
                <img src="images/gospodar.jpg" alt="Gospodar svibnja">
                <h2>Gospodar svibnja</h2>
                <p>Brzopotezni turnir koji se već nekoliko godina svakog svibnja organizira u Starigradu.</p>
                <a href="#">Više o tome...</a>
            </article>
            <article class="Memorijal col-lg-4 col-sm-6">
                <img src="images/memorijal.jpg" alt="Memorijal Stjepana Kamenečkog">
                <h2>Memorija Stjepana Kamenečkog</h2>
                <p>Kadetski i juniorski turnir koji se već nekoliko godina organizira u Starigradu.</p>
                <a href="#">Više o tome...</a>
            </article>
            <article class="STEM col-lg-4 col-sm-6">
                <img src="images/STEM.jpg" alt="STEM">
                <h2>STEM Games</h2>
                <p>Studentski turnir koji se organizira već nekoliko godina u Istri.</p>
                <a href="#">Više o tome...</a>
            </article>

            <article class="Drzavno col-lg-4 col-sm-6">
                <img src="images/drzavno.jpg" alt="Kadetsko državno prvenstvo">
                <h2>Kadetsko državno prvenstvo</h2>
                <p>Pojedinačno prvenstvo U-16 šahista.</p>
                <a href="#">Više o tome...</a>
            </article>
            <article class="Juniorska col-lg-4 col-sm-6">
                <img src="images/juniorskaliga.jpeg" alt="Juniorska liga">
                <h2>Juniorska liga</h2>
                <p>Ekipno prvenstvo na četri ploče između U-20 šahista.</p>
                <a href="#">Više o tome...</a>
            </article>
            <article class="Seniorska col-lg-4 col-sm-6">
                <img src="images/seniorskaliga.jpg" alt="Seniorska liga">
                <h2>Seniorska liga</h2>
                <p>Ekipno prvenstvo na šest ploči između šahista bilo koje dobi.</p>
                <a href="#">Više o tome...</a>
            </article>
            </div>
        </section>

        <section class="Druzenja">
            <h1>Druženja</h1>
            <div class="row">
            <article class="Garry col-lg-4 col-sm-6">
                <img src="images/renesansni.png" alt="Simultanka na renesansnom festivalu">
                <h2>Simultanka (Renesansni festival)</h2>
                <p>Simultanka protiv Garrya Kasparova.</p>
                <a href="#">Više o tome...</a>
            </article>
            <article class="Koprivnica col-lg-4 col-sm-6">
                <img src="images/koprivnica.jpg" alt="Simultanka u Koprivnica">
                <h2>Simultanka (Koprivnica)</h2>
                <p>Simultanka protiv majstora šaha.</p>
                <a href="#">Više o tome...</a>
            </article>
            <article class="Belot col-lg-4 col-sm-6">
                <img src="images/belot.jpg" alt="Šah i belot">
                <h2>Šah i belot</h2>
                <p>Šah i belot u Koprivnici na istom mjestu u isto vrijeme.</p>
                <a href="#">Više o tome...</a>
            </article>
            </div>
        </section>

    </main>
</body>
</html>